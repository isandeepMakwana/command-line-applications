from selenium import webdriver

#class to play a music video on youtube
class music():
    def __init__(self):
        self.driver = webdriver.Chrome(executable_path='C:/Users/Waseem/.wdm/drivers/chromedriver/83.0.4103.39/win32/chromedriver_win32 (2)/chromedriver.exe')


    def play(self, name):
        self.name = name
        self.driver.get(url="https://www.youtube.com/results?search_query="+ name)
        video = self.driver.find_element_by_xpath('//*[@id="dismissable"]')
        video.click()

#calling the music automation class
#bot = music()
#bot.play("edureka automation")