from selenium import webdriver


class Movie():
    def __init__(self):
        self.driver = webdriver.Chrome(executable_path='C:/Users/Waseem/.wdm/drivers/chromedriver/83.0.4103.39/win32/chromedriver_win32 (2)/chromedriver.exe')

    def movie_review(self, name):
        self.driver.get(url="https://www.google.com")
        search = self.driver.find_element_by_xpath('//*[@id="tsf"]/div[2]/div[1]/div[1]/div/div[2]/input')
        search.click()
        search.send_keys(name + " movie reviews")
        submit = self.driver.find_element_by_xpath('//*[@id="tsf"]/div[2]/div[1]/div[2]/div[2]/div[2]/center/input[1]')
        submit.click()


#bot = Movie()
#bot.movie_review("Pursuit of happiness")
