import pyttsx3 as p


engine = p.init()
volume = engine.getProperty("volume")
print(volume)
engine.say("Hello, how are you doing?")
engine.say("what would you like me to do?")
engine.runAndWait()