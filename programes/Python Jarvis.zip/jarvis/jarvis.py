import speech_recognition as sr
import pyttsx3 as p
from web_auto import *
from web_auto1 import *
from web_automation import *
from recommendations import *
from words import *

#initial conversation
r1 = sr.Recognizer()
engine = p.init()
engine.say("hello sire, how are you today?")
engine.runAndWait()
with sr.Microphone() as source:
    r1.adjust_for_ambient_noise(source)
    print("how are you today?")
    audio = r1.listen(source)
    try:
        text = r1.recognize_google(audio)
        print(text)
    except sr.UnknownValueError:
        print("")
    except sr.RequestError as e:
        print("")

#cue for giving instructions
engine.say("what would you like me to do?")
engine.runAndWait()
print("what do you want?")

#giving instructions
r2 = sr.Recognizer()
with sr.Microphone() as source:
    r2.adjust_for_ambient_noise(source)
    audio = r2.listen(source)
    try:
        instruction = r2.recognize_google(audio)
        print(text)
    except sr.UnknownValueError:
        print("")
    except sr.RequestError as e:
        print("")

#getting info from wiki
r3 = sr.Recognizer()
if "information" in instruction:
    engine.say("information about what?")
    engine.runAndWait()
    with sr.Microphone() as source1:
        audio2 = r3.listen(source1)
        try:
            information = r3.recognize_google(audio2)
            bot = info()
            bot.get_info(information)
        except sr.UnknownValueError:
            print("")
        except sr.RequestError as e:
            print("")

#movie rating
r4 = sr.Recognizer()
if "review" in instruction:
    engine.say("what is the name of the movie?")
    engine.runAndWait()
    with sr.Microphone() as source2:
        audio3 = r4.listen(source2)
        try:
            rating = r4.recognize_google(audio3)
            bot = Movie()
            bot.movie_review(rating)
        except sr.UnknownValueError:
            print("")
        except sr.RequestError as e:
            print("")

#playing music
r5 = sr.Recognizer()
if "music" in instruction:
    engine.say("which artist should i play?")
    engine.runAndWait()
    with sr.Microphone() as source3:
        audio4 = r5.listen(source3)
        try:
            video = r5.recognize_google(audio4)
            bot = music()
            bot.play(video)
        except sr.UnknownValueError:
            print("")
        except sr.RequestError as e:
            print("")

#movie recommendation
if "recommendation" in instruction:
    engine.say("Here are a list of movies you can choose to watch from")
    engine.runAndWait()
    bot = recom()
    bot.recom_info()

#getting meaning of a word
r6 = sr.Recognizer()
if "meaning" in instruction:
    engine.say("which word sire?")
    engine.runAndWait()
    with sr.Microphone() as source4:
        audio5 = r6.listen(source4)
        try:
            word = r6.recognize_google(audio5)
            mean(word)
        except sr.UnknownValueError:
            print("")
        except sr.RequestError as e:
            print("")

#getting the translation in spanish
r7 = sr.Recognizer()
if "translate" in instruction:
    engine.say("what do you want to translate sire?")
    engine.runAndWait()
    with sr.Microphone() as source5:
        audio6 = r7.listen(source5)
        try:
            word1 = r7.recognize_google(audio6)
            translate(word1)
        except sr.UnknownValueError:
            print("")
        except sr.RequestError as e:
            print("")

