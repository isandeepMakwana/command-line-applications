import speech_recognition as sr
import pyttsx3 as p

r = sr.Recognizer()
engine = p.init()

with sr.Microphone() as source:
    print("now")
    audio = r.listen(source)

    try:
        print(r.recognize_google(audio))
    except sr.UnknownValueError:
        print("")
    except sr.RequestError as e:
        print("")